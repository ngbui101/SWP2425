
#ifndef __BOARD_H_
#define __BOARD_H_

#include "BG96_Common.h"
#include "BG96_ATCommand.h"
#include "BG96_GNSS.h"
#include "BG96_Serial.h"

#endif
